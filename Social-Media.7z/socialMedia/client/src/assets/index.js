import NoProfile from "./userprofile.png";
import BgImage from "./img.jpeg";
import emailnobg from "./emailnobg.png"
import sitelogo from "./sitelogo.png"
export { NoProfile, BgImage, emailnobg, sitelogo};
